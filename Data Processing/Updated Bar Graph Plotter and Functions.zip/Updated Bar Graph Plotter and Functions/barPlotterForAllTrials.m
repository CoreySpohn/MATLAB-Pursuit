clear
close all

nearestReplicateAndSpeciesMean = [];pathReplicateAndSpeciesMean = [];speedReplicateAndSpeciesMean = [];timeReplicateAndSpeciesMean = [];nearestStandardDeviation = [];pathStandardDeviation = [];speedStandardDeviation = [];timeStandardDeviation = [];

%This is how we find the folders with the Trial Data. It looks for a folder
%starting with 'Trial' and takes the last 2 characters from the folder's
%name. For it to work you want to save data in a folder named 'Trial X',
%where X is an integer. The folders have to be saved in the same place as
%this program
allTrials = [];
files = dir;
directoryNames = {files([files.isdir]).name};
directoryNames = directoryNames(~ismember(directoryNames,{'.','..'}));
for directory = directoryNames
   directoryAsString = directory{1};
   if directoryAsString(1:5)=='Trial'
       allTrials = [allTrials str2num(directoryAsString(end-1:end))];
   end
end
allTrials = sort(allTrials);

maxReplicates =21; %Change this if any one trial has more than 21 replicates
maxPeopleInATrial = 15; % change this if any one replicate has more than 15 participants

for trial = allTrials
    
    %The multipliers like 1/1000 are unit conversions, in our experiment
    %the cube measured distance in mm so we change that to meters, and the
    %cube had a 60 hz sampling rate which we convert to seconds
    meanNeighborInEachReplicate=1/1000.*findAveragesInEachReplicate(maxReplicates,maxPeopleInATrial,trial,@minAverageSplit);
    meanPathInEachReplicate=1/1000.*findAveragesInEachReplicate(maxReplicates,maxPeopleInATrial,trial,@totDistanceSplit);
    meanSpeedInEachReplicate=60/1000.*findAveragesInEachReplicate(maxReplicates,maxPeopleInATrial,trial,@avgVelocitySplit);
    meanTimeInEachReplicate=1/60.*findAveragesInEachReplicate(maxReplicates,maxPeopleInATrial,trial,@avgTimeSplit);
    
    %This will have to be changed manually depending on your trial numbers
    %and number of human/robot sharks/minnows in each trial
    if trial == 3, hShark = 2;hMinnow = 10;rShark = 0;rMinnow =0;
    elseif trial==4, hShark = 2;hMinnow = 5;rShark = 0;rMinnow =0;
    elseif trial==7, hShark = 0;hMinnow = 10;rShark = 3;rMinnow =0;
    elseif trial==8, hShark = 0;hMinnow = 5;rShark = 3;rMinnow =0;
    elseif trial==15, hShark = 2;hMinnow = 8;rShark = 0;rMinnow =2;
    elseif trial==16, hShark = 2;hMinnow = 3;rShark = 0;rMinnow =2;
    elseif trial==17, hShark = 1; hMinnow = 8;rShark = 0;rMinnow =2;
    else, hShark = 2;hMinnow = 10;rShark = 0;rMinnow =0;
    end
    
    nearestReplicateAndSpeciesMean = [nearestReplicateAndSpeciesMean; meanCalculator(meanNeighborInEachReplicate, hShark,hMinnow,rShark,rMinnow)];
    pathReplicateAndSpeciesMean = [pathReplicateAndSpeciesMean; meanCalculator(meanPathInEachReplicate, hShark,hMinnow,rShark,rMinnow)];
    speedReplicateAndSpeciesMean = [speedReplicateAndSpeciesMean; meanCalculator(meanSpeedInEachReplicate, hShark,hMinnow,rShark,rMinnow)];
    timeReplicateAndSpeciesMean = [timeReplicateAndSpeciesMean; meanCalculator(meanTimeInEachReplicate, hShark,hMinnow,rShark,rMinnow)];

    nearestStandardDeviation = [nearestStandardDeviation; standardDeviationCalculator(meanNeighborInEachReplicate, hShark,hMinnow,rShark,rMinnow)];
    pathStandardDeviation = [pathStandardDeviation; standardDeviationCalculator(meanPathInEachReplicate, hShark,hMinnow,rShark,rMinnow)];
    speedStandardDeviation = [speedStandardDeviation; standardDeviationCalculator(meanSpeedInEachReplicate, hShark,hMinnow,rShark,rMinnow)];
    timeStandardDeviation = [timeStandardDeviation; standardDeviationCalculator(meanTimeInEachReplicate, hShark,hMinnow,rShark,rMinnow)];
end

barGraphPlotter(nearestReplicateAndSpeciesMean,nearestStandardDeviation,'Nearest Neighbor Distance Broken Down By Species','Nearest Neighbor (m)')
barGraphPlotter(pathReplicateAndSpeciesMean,pathStandardDeviation,'Path Length Broken Down By Species','Path Length (m)')
barGraphPlotter(speedReplicateAndSpeciesMean,speedStandardDeviation,'Average Speed Broken Down By Species','Speed (m/s)')
barGraphPlotter(timeReplicateAndSpeciesMean,timeStandardDeviation,'Average Time Broken Down By Species','Time (sec)')