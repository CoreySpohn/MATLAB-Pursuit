function [] = barGraphPlotter(means,standardDeviations,graphTitle,yLabel)
figure('pos',[10 10 800 800])
barGraph=bar(means)
set(gca,'XTickLabel', {'A','B','C','D','E','F','G'},'fontsize',12)
standardDeviations = transpose(standardDeviations);
for k1 = 1:size(barGraph,2)
    ctr(k1,:) = bsxfun(@plus, barGraph(k1).XData, [barGraph(k1).XOffset]');             % Centres Of Bar Groups
    ydt(k1,:) = barGraph(k1).YData;                                                 % Y-Data Of Bar Groups
end
hold on
for k1 = 1:size(barGraph,2)
    errorbar(ctr(k1,:), ydt(k1,:), standardDeviations(k1,:), '.r')
end
hold off

title(graphTitle)
xlabel('Trial')
ylabel(yLabel)
colormap(jet);
grid on
l = cell(1,4);
l{1}='Human Minnow'; l{2}='Human Shark'; l{3}='Robot Minnow'; l{4}='Robot Shark';
legend(barGraph,l,'Location','southoutside','Orientation','Horizontal');

end

