function [ averagesInEachReplicate ] = findAveragesInEachReplicate(maxReplicates,maxPeopleInATrial,trial,averager)
   
    averagesInEachReplicate = NaN(maxReplicates,maxPeopleInATrial);
    
    %loop through every replicate
    for replicate =1:maxReplicates
        
        %some replicates have an error so the try catch statement ignores replicates with errors
        %the code to load a file in is copied from the position_extraction script
        try
            graphPositions = getReplicatePositionData(trial,replicate);
            
            %Calling function for data anlysis and storing function return values
            averagesInEachReplicate(replicate,1:size(graphPositions,2)/2) = averager(graphPositions);
        catch
        end
        
    end
end

