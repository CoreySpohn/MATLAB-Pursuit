function [standardDeviation] = standardDeviationCalculator(meanInEachReplicate,hShark,hMinnow,rShark,rMinnow)

standardDeviation = [std(mean(meanInEachReplicate(:,1:hMinnow),2,'omitnan'),'omitnan') std(mean(meanInEachReplicate(:,1+hMinnow:hMinnow+hShark),2,'omitnan'),'omitnan') std(mean(meanInEachReplicate(:,1+hMinnow+hShark:hMinnow+hShark+rMinnow),2,'omitnan'),'omitnan') std(mean(meanInEachReplicate(:,1+hMinnow+hShark+rMinnow:hMinnow+hShark+rMinnow+rShark),2,'omitnan'),'omitnan') NaN NaN NaN];

end