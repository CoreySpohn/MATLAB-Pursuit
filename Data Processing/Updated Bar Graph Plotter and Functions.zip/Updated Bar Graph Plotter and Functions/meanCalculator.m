function [replicateAndSpeciesMean] = meanCalculator(meanInEachReplicate,hShark,hMinnow,rShark,rMinnow)

replicateMean = mean(meanInEachReplicate,'omitnan');
replicateAndSpeciesMean = [mean(replicateMean(1:hMinnow),'omitnan') mean(replicateMean(hMinnow+1:hShark+hMinnow),'omitnan') mean(replicateMean(hShark+hMinnow+1:hShark+hMinnow+rMinnow),'omitnan') mean(replicateMean(rMinnow+hShark+hMinnow+1:hShark+hMinnow+rMinnow+rShark),'omitnan') NaN NaN NaN];

end

